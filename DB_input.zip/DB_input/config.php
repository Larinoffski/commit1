<head>
    <meta charset="UTF-8">
</head>
<?php
$dblocation = "localhost";
$dbname = "films";
$dbuser = "root";
$dbpasswd = "1";