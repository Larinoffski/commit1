<?php
include_once "config.php";
$dbcnx = mysql_connect($dblocation,$dbuser,$dbpasswd);
$dbSelected = mysql_select_db($dbname, $dbcnx);
if($dbcnx){
    echo"ok<br>";
}
if($dbSelected) {
    echo "ok";
}
$query = "INSERT INTO films VALUES ('','John','кенг','2000','usa','comedy','tarantino Q')";
mysql_query($query);
mysql_close();
