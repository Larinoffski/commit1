<?php
include_once "config.php";

$dbcnx = mysql_connect($dblocation,$dbuser,$dbpasswd);
$dbSelected = mysql_select_db($dbname, $dbcnx);

$query="SELECT * FROM films";
$result=mysql_query($query);

/*if($result){
    while($film = mysql_fetch_array($result)){
        echo "Название - " . $film['name'] . "<br>";
        echo "RUS - " . $film ['runame'] . "<br>";
        echo "Год - " . $film['year'] . "<br>";
        echo "Страна - " . $film['country'] . "<br>";
        echo "Жанр - " . $film['genre'] . "<br>";
        echo "Режиссер - " . $film['director'] . "<br>";
    }
}
*/

$num=mysql_numrows($result);
echo"<br>$num<br>";
$i=0;
while ($i < $num) {

    $name=mysql_result($result,$i,"name");
    $runame=mysql_result($result,$i,"runame");
    $year=mysql_result($result,$i,"year");
    $country=mysql_result($result,$i,"country");
    $genre=mysql_result($result,$i,"genre");
    $director=mysql_result($result,$i,"director");
    echo"$name<br>";
    $i++;
}

mysql_close();